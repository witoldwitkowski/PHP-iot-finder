#!/bin/sh
# Installs iotscan system-wide (default /usr/local). Run with sudo.
set -eu
here=$(cd "$(dirname "$0")" && pwd)
prefix=${PREFIX:-/usr/local}
install -Dm755 "$here/iotscan" "$prefix/bin/iotscan"
install -Dm644 "$here/man/iotscan.1" "$prefix/share/man/man1/iotscan.1"
install -Dm644 "$here/packaging/iotscan.desktop" "$prefix/share/applications/iotscan.desktop"
install -Dm644 "$here/packaging/iotscan.svg" "$prefix/share/icons/hicolor/scalable/apps/iotscan.svg"
mkdir -p "$prefix/share/bash-completion/completions"
"$prefix/bin/iotscan" completions bash > "$prefix/share/bash-completion/completions/iotscan"
echo "Installed to $prefix. Try: iotscan selftest && iotscan"
echo "Optional faster discovery: sudo setcap cap_net_raw+ep $prefix/bin/iotscan"
